<?php

namespace App\Controllers;

class Resep extends BaseController
{
    public function index()
    {
        $data['resep'] = [];

        try {

            $client = \Config\Services::curlrequest();

            $response = $client->request(
                'GET',
                'https://www.themealdb.com/api/json/v1/1/search.php?s='
            );

            $result = json_decode($response->getBody(), true);

            if(isset($result['meals'])){

                $data['resep'] = $result['meals'];

            }

        } catch (\Exception $e){

            $data['error'] = $e->getMessage();

        }

        return view('resep_view', $data);
    }

    public function detail($id)
    {
        try {

            $client = \Config\Services::curlrequest();

            $response = $client->request(
                'GET',
                'https://www.themealdb.com/api/json/v1/1/lookup.php?i=' . $id
            );

            $result = json_decode($response->getBody(), true);

            $data['detail'] = $result['meals'][0];

            return view('detail_view', $data);

        } catch (\Exception $e){

            echo $e->getMessage();

        }
    }
}