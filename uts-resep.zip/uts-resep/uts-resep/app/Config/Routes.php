<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Resep::index');
$routes->get('/detail/(:any)', 'Resep::detail/$1');
