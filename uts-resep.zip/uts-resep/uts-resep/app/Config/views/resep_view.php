<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <title>Kumpulan Resep Masakan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

    <h1 class="text-center mb-5">
        🍜 Kumpulan Resep Masakan
    </h1>

    <div class="row">

        <?php if(!empty($resep)): ?>

            <?php foreach($resep as $r): ?>

                <div class="col-md-4 mb-4">

                    <div class="card shadow h-100">

                        <img 
                            src="<?= $r['thumb']; ?>" 
                            class="card-img-top"
                            style="height:250px; object-fit:cover;"
                        >

                        <div class="card-body">

                            <h5 class="fw-bold">
                                <?= $r['title']; ?>
                            </h5>

                            <p>
                                ⏰ <?= $r['times']; ?>
                            </p>

                            <p>
                                🍽️ <?= $r['portion']; ?>
                            </p>

                            <p>
                                🔥 <?= $r['dificulty']; ?>
                            </p>

                            <a 
                                href="/detail/<?= $r['key']; ?>" 
                                class="btn btn-primary w-100"
                            >
                                Lihat Detail
                            </a>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="alert alert-danger">
                Data gagal diambil dari API
            </div>

        <?php endif; ?>

    </div>

</div>

</body>
</html>