<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <title>Detail Resep</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-light">

<div class="container mt-5">

    <a href="/" class="btn btn-secondary mb-4">
        ← Kembali
    </a>

    <div class="card shadow">

        <img 
            src="<?= $detail['thumb']; ?>" 
            class="card-img-top"
            style="height:400px; object-fit:cover;"
        >

        <div class="card-body">

            <h2 class="mb-3">
                <?= $detail['title']; ?>
            </h2>

            <p>
                ⏰ <?= $detail['times']; ?>
            </p>

            <p>
                🍽️ <?= $detail['servings']; ?>
            </p>

            <hr>

            <h4>Bahan-Bahan</h4>

            <ul>

                <?php foreach($detail['ingredient'] as $b): ?>

                    <li><?= $b; ?></li>

                <?php endforeach; ?>

            </ul>

            <hr>

            <h4>Cara Memasak</h4>

            <ol>

                <?php foreach($detail['step'] as $s): ?>

                    <li><?= $s; ?></li>

                <?php endforeach; ?>

            </ol>

        </div>

    </div>

</div>

</body>
</html>