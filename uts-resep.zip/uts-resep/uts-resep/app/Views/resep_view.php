<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kumpulan Resep Masakan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background:#f5f5f5;
        }

        .card{
            transition:0.3s;
            border:none;
            border-radius:15px;
            overflow:hidden;
        }

        .card:hover{
            transform:translateY(-5px);
        }

        .card img{
            height:250px;
            object-fit:cover;
        }

    </style>

</head>

<body>

<div class="container py-5">

    <h1 class="text-center mb-5">
        🍜 Kumpulan Resep Masakan
    </h1>

    <div class="row">

        <?php if(!empty($resep)): ?>

            <?php foreach($resep as $r): ?>

                <div class="col-md-4 mb-4">

                    <div class="card shadow h-100">

                        <img 
                            src="<?= $r['strMealThumb']; ?>" 
                            class="card-img-top"
                        >

                        <div class="card-body">

                            <h3 class="fw-bold">
                                <?= $r['strMeal']; ?>
                            </h3>

                            <p>
                                🌍 <?= $r['strArea']; ?>
                            </p>

                            <p>
                                🍽️ <?= $r['strCategory']; ?>
                            </p>

                            <a 
                                href="/detail/<?= $r['idMeal']; ?>" 
                                class="btn btn-primary w-100"
                            >
                                Lihat Resep
                            </a>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="alert alert-danger">

                Data gagal diambil dari API

                <?php if(isset($error)): ?>

                    <br><br>

                    <?= $error; ?>

                <?php endif; ?>

            </div>

        <?php endif; ?>

    </div>

</div>

</body>
</html>