<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Resep</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background:#f5f5f5;
        }

        .card{
            border:none;
            border-radius:20px;
            overflow:hidden;
        }

        .card img{
            height:450px;
            object-fit:cover;
        }

    </style>

</head>

<body>

<div class="container py-5">

    <a href="/" class="btn btn-secondary mb-4">
        ← Kembali
    </a>

    <div class="card shadow">

        <img 
            src="<?= $detail['strMealThumb']; ?>" 
            class="card-img-top"
        >

        <div class="card-body p-4">

            <h1 class="mb-3">
                <?= $detail['strMeal']; ?>
            </h1>

            <p>
                🌍 <?= $detail['strArea']; ?>
            </p>

            <p>
                🍽️ <?= $detail['strCategory']; ?>
            </p>

            <hr>

            <h3>Bahan-Bahan</h3>

            <ul>

                <?php for($i = 1; $i <= 20; $i++): ?>

                    <?php if(!empty($detail['strIngredient'.$i])): ?>

                        <li>

                            <?= $detail['strIngredient'.$i]; ?>

                            - 

                            <?= $detail['strMeasure'.$i]; ?>

                        </li>

                    <?php endif; ?>

                <?php endfor; ?>

            </ul>

            <hr>

            <h3>Cara Memasak</h3>

            <p style="text-align:justify;">

                <?= $detail['strInstructions']; ?>

            </p>

        </div>

    </div>

</div>

</body>
</html>